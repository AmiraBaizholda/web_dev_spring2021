#!c:\users\jojor\desktop\web-dev\webdev2021-rk\webka-lab9\hh-back\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
