def sum_double(a, b):
  sum = a + b
  if a == b:
    sum = sum * 2
  return sum