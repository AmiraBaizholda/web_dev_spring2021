a=int(input())
b=int(input())
print(max(a,b))