a=int(input())
b=int(input())
a=a**2
b=b**2
c=(a+b)**0.5

print(float(c))
 