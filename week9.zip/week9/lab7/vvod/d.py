n=int(input())
k=int(input())
print(k%n)