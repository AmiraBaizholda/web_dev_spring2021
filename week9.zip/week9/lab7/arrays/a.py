a = list(map(int, input().split()))
int i = 0
for i in range(len(a)):
    if i%2==0:
        print(a[i],end=" ")