a=[int(i) for i in input().split()]
maxi=max(a)
indexi = a.index(max(a))
print(maxi, end=' ')
print(indexi)